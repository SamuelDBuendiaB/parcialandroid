package com.example.parcial3;

import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth auth;
    Button btn,perfil,enc,usuarios,prin;
    TextView nombre,uid;
    FirebaseUser user;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();
        btn = findViewById(R.id.logOUT);
        nombre = findViewById(R.id.detaller);
        user = auth.getCurrentUser();
        perfil = findViewById(R.id.perf);
        enc = findViewById(R.id.encuesta);
        //uid = findViewById(R.id.uid);
        usuarios = findViewById(R.id.usuarios);
        prin = findViewById(R.id.prin);


        if (user == null) {
            Intent inter = new Intent(getApplicationContext(), singin.class);
            startActivity(inter);
            finish();
        } else {

            nombre.setText(user.getEmail());
        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent inter = new Intent(getApplicationContext(), singin.class);
                startActivity(inter);
                finish();

            }
        });

        prin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), principal2.class);
                startActivity(intent);
            }
        });


        perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inter = new Intent(getApplicationContext(), perfil.class);
                startActivity(inter);

            }
        });
        enc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inter = new Intent(getApplicationContext(), envdatos.class);
                startActivity(inter);

            }
        });

        usuarios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent inter = new Intent(getApplicationContext(), mostrarusers.class);
                // startActivity(inter);
                //finish();
                usuarios.setVisibility(View.GONE);
                enc.setVisibility(View.GONE);
                perfil.setVisibility(View.GONE);
                btn.setVisibility(View.GONE);
                nombre.setVisibility(View.GONE);

                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.main, new Usuariosfrag()).commit();


            }
        });
    }

        @Override
        public void onBackPressed() {
            // Aquí verificamos si estamos en el fragmento que queremos manejar al presionar "atrás"
            if (getSupportFragmentManager().findFragmentById(R.id.main) instanceof Usuariosfrag) {
                // Si estamos en el fragmento Usuariosfrag, volvemos al Activity principal
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                // Si no estamos en el fragmento Usuariosfrag, dejamos que la actividad maneje el comportamiento predeterminado
                super.onBackPressed();
            }
        }
    }


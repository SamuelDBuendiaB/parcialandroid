package com.example.parcial3;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Usuariosfrag extends Fragment {

RecyclerView recyclerView;
adaptarusuarios adaptarusuarios;
List<modelUsers> usersList;
    FirebaseUser fuser;
    DatabaseReference ref;
    public Usuariosfrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_usuariosfrag, container, false);

        recyclerView = view.findViewById(R.id.usuarios_recicle);

        // propiedades
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // iniciar lista de usuarios
        usersList = new ArrayList<>();

        // traer todos los usuarios
        getAllUsers();

        return view;
    }

    private void getAllUsers() {
        // traer usuarios atuales
       fuser = FirebaseAuth.getInstance().getCurrentUser();
        //ruta de los datos de los usuarios "usuario"
       ref = FirebaseDatabase.getInstance().getReference("usuario");
        //todos los datos
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                usersList.clear();
                for (DataSnapshot ds : snapshot.getChildren()){
                    modelUsers modelUsers = ds.getValue(modelUsers.class);
                    // todos menos el usuarios que esta en la app en el momento
                    if ((modelUsers != null && modelUsers.getUsuarioid() != null && fuser != null && !modelUsers.getUsuarioid().equals(fuser.getUid()))){
                        usersList.add(modelUsers);
                    }else {
                        // adaptador
                        adaptarusuarios = new adaptarusuarios(getActivity(), usersList);
                        // poner adaptador en recicly view
                        recyclerView.setAdapter(adaptarusuarios);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
package com.example.parcial3;

import android.Manifest;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;



import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;


import java.util.HashMap;


public class perfil extends AppCompatActivity {

    TextView nombre1,edad1,gusto1;

    DatabaseReference informacion;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;
    StorageReference refstorage;
    String ubicacion_imagen ="imagener_perfil/";
    ImageView imagen;
    FloatingActionButton fab;
    ProgressDialog pd;

    private static final int CAMERA_REQUEST_CODE=100;
    private static final int ESPACIO_REQUEST_CODE=200;
    private static final int ELEJIDA_GALERIA_CODE=300;
    private static final int ELEJIDA_CAMARA_CODE=400;

    String camaraper[];
    String espacioper[];
    Uri img_uri;

    String perfil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        nombre1 = findViewById(R.id.nombre1);
        edad1 = findViewById(R.id.edad1);
        gusto1 = findViewById(R.id.gusto1);
        imagen = findViewById(R.id.imagenper);
        fab = findViewById(R.id.opciones);

        pd = new ProgressDialog(this);


        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        informacion = FirebaseDatabase.getInstance().getReference("usuario");//referencia
        refstorage = FirebaseStorage.getInstance().getReference();// referencia

        camaraper = new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        espacioper = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};



        informacion.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()){
                    // DATOS DE FIREBASE
                    //DATOS REGISTRADOS
                    String nombres = snapshot.child("nombre").getValue(String.class);
                    String edads = snapshot.child("edad").getValue(String.class);
                    String gustos = snapshot.child("gusto").getValue(String.class);
                    String perfil = snapshot.child("imagen").getValue(String.class);

                    nombre1.setText(nombres);
                    edad1.setText(edads);
                    gusto1.setText(gustos);

                    try {
                        // Si recibe la imagen
                        Picasso.get().load(perfil).into(imagen);

                    }catch (Exception e){
                        // si no recibe imagen
                        Picasso.get().load(R.drawable.ic_launcher_background).into(imagen);
                    }

                    Log.d("FirebaseData", "Datos mostrados");

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("Fallo la lectura: " + error.getCode());


            }
        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cuadro_opciones();
            }
        });



    }

    private boolean verificarespacio(){
        boolean resultado2 = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return resultado2;
    }
    private void pedirpermisoespacio(){
        ActivityCompat.requestPermissions(this,espacioper,ESPACIO_REQUEST_CODE);
    }



    private boolean verificarcamara(){

        boolean result1 = ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)
                ==(PackageManager.PERMISSION_GRANTED);

        boolean result = ContextCompat.checkSelfPermission(this,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                ==(PackageManager.PERMISSION_GRANTED);
        return result && result1;
    }
    private void pedirpermisocamara(){
      ActivityCompat.requestPermissions(this,camaraper,CAMERA_REQUEST_CODE);
    }

    private void cuadro_opciones() {

        String opcions[] = {"Foto","Nombre","Edad","Gustos"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Elejir opcion");
        builder.setItems(opcions, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // elemenetos del este
                if (which == 0){
                    // Cambiar foto
                    pd.setMessage("Actualizando foto");
                    perfil = "imagen";
                    galeria();

                }else if (which == 1){
                    // Cambiar nombre
                    pd.setMessage("Actualizando");
                    actualizardatos("nombre");

                }  else if (which == 2){
                // Cambiar edad
                    pd.setMessage("Actualizando");
                    actualizardatos("edad");


                } else if (which == 3){
                    // Cambiar gusto
                    pd.setMessage("Actualizando");
                    actualizardatos("gusto");


                }

            }
        });
        builder.create().show();
    }

    private void actualizardatos(String key) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update "+ key); // ejm update nombre o update edad y asi

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(linearLayout.VERTICAL);
        linearLayout.setPadding(10,10,10,10);
        EditText editText = new EditText(this);
        editText.setHint("Ingresar "+ key);// segun lo que elija aparece la pista
        linearLayout.addView(editText);

        builder.setView(linearLayout);

        // agregar button
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // input text del edit text
                String value = editText.getText().toString().trim();
                if (!TextUtils.isEmpty(value)){
                    pd.show();
                    HashMap< String, Object> result = new HashMap<>();
                    result.put(key, value);
                    informacion.child(user.getUid()).updateChildren(result)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    //
                                    pd.dismiss();
                                    Toast.makeText(perfil.this,"Actualizado con exito",Toast.LENGTH_SHORT).show();

                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // operacion fallida tirar progreso a la basura
                                    pd.dismiss();
                                    Toast.makeText(perfil.this,""+e.getMessage(),Toast.LENGTH_SHORT).show();

                                }
                            });
                }else{
                    Toast.makeText(perfil.this,"No dejar en blanco",Toast.LENGTH_SHORT).show();
                }

            }
        });
        // agregar buttones
        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        // crear y mostrar input
        builder.create().show();



    }

    private void galeria() {
        // abre el cosito para caleria
        String opcions[] = {"Camara","Galeria"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Elegir imagen desde");
        builder.setItems(opcions, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // elemenetos del este
                if (which == 0){
                    // Camara
                    if (!verificarcamara()){
                        pedirpermisocamara();
                    }else{
                        selcamera();
                    }

                }else if (which == 1){
                    // galleria
                    if(!verificarespacio()){
                        pedirpermisoespacio();
                    }else{

                        selgaleria();
                    }

                }

            }
        });
        builder.create().show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        // por si el usuario no da permiso para algo

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case CAMERA_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    boolean aceptado = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean aceptadoespacio = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    if (aceptado && aceptadoespacio) {
                        // Permisos no  aceptados
                        Toast.makeText(this, "Habilitar permisos porfavor", Toast.LENGTH_SHORT).show();
                    } else {
                        // Permisos aceptado camara

                        selcamera();

                    }
                }

            }
            break;
            case ESPACIO_REQUEST_CODE: {
                // si no da permiso para galeria
                if (grantResults.length > 0) {
                    boolean aceptadoespacio = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    if (aceptadoespacio) {
                        // Permisos no aceptados
                        Toast.makeText(this, "Habilitar permisos porfavor", Toast.LENGTH_SHORT).show();


                    } else {
                        // Permisos aceptados galeria

                        selgaleria();

                    }
                }

            }
            break;


        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // metodo llamado luego de elejir de galeria o foto
        if (resultCode == RESULT_OK){
            if (requestCode == ELEJIDA_GALERIA_CODE){
                // imagen elejida de la galleria tomar uri de la imagen
                img_uri = data.getData();
                
                subirfoto(img_uri);

            }if (resultCode == ELEJIDA_CAMARA_CODE){
                // imagen elejida de la camara tomar uri de la imagen
                img_uri = data.getData();
                subirfoto(img_uri);
            }
        }

    }

    private void subirfoto(final Uri img_uri) {
        // ruta de las imagenes
        String ruta = ubicacion_imagen+ ""+user.getUid();
        pd.show();
        StorageReference ref2 = refstorage.child(ruta);
        ref2.putFile(img_uri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // imagen subida bien al espacio
                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful());
                        Uri downloaduri = uriTask.getResult();
                        // verificar si imagen subida o no url recibida
                        if(uriTask.isSuccessful()){
                            // imagen subida
                            HashMap<String, Object> results = new HashMap<>();

                            results.put(perfil,downloaduri.toString());
                            informacion.child(user.getUid()).updateChildren(results)

                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            pd.dismiss();
                                            Toast.makeText(perfil.this,"subido con exito",Toast.LENGTH_SHORT).show();
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            pd.dismiss();
                                            Toast.makeText(perfil.this,"Error subiendo 322",Toast.LENGTH_SHORT).show();
                                        }
                                    });



                        }else{
                            //error
                            pd.dismiss();
                            Toast.makeText(perfil.this,"Error linea 331",Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        //error al subirla
                        pd.dismiss();
                        Toast.makeText(perfil.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });


    }

    private void selcamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE,"Temp pic");
        values.put(MediaStore.Images.Media.DESCRIPTION,"Temp desc");
        // poner imagen en uri
        img_uri = perfil.this.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);


        // intet para la camara

        Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cam.putExtra(MediaStore.EXTRA_OUTPUT,img_uri);
        startActivityForResult(cam,ELEJIDA_CAMARA_CODE);

    }

    private void selgaleria() {
        // Elejir imagen de galeria
        Intent galeria = new Intent(Intent.ACTION_PICK);
        galeria.setType("image/*");
        startActivityForResult(galeria,ELEJIDA_GALERIA_CODE);


    }
}


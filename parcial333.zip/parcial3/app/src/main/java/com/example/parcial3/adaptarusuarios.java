package com.example.parcial3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class adaptarusuarios extends RecyclerView.Adapter<adaptarusuarios.myholder>{

    Context context;
    List<modelUsers> usersList;

    //Construsctor

    class myholder extends RecyclerView.ViewHolder{
        // para agreagar mas text i asi

        ImageView xavatar;
        TextView xnombretv , xemailtv, xedadtv;

        public myholder(@NonNull View itemView) {
            super(itemView);
            // iniciar vistas
            xavatar = itemView.findViewById(R.id.avatar);
            xnombretv = itemView.findViewById(R.id.nombreTv);
            xemailtv = itemView.findViewById(R.id.emailTv);
            xedadtv = itemView.findViewById(R.id.edadtv);

        }
    }
    public adaptarusuarios(Context context, List<modelUsers> usersList) {
        this.context = context;
        this.usersList = usersList;
    }

    @NonNull
    @Override
    public myholder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        // layount(row_users.xml)
        View view = LayoutInflater.from(context).inflate(R.layout.row_users, viewGroup,false);
        return new myholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myholder holder, int i) {
        // traer data
        String  Usimg = usersList.get(i).getImagen();
        String  Usname = usersList.get(i).getNombre();
        String  UsCorreo = usersList.get(i).getCorreo();
        String Usedad = usersList.get(i).getEdad();

        // poner los datos
        holder.xnombretv.setText(Usname);
        holder.xemailtv.setText(UsCorreo);
        holder.xedadtv.setText(Usedad);

        try {
            Picasso.get().load(Usimg).placeholder(R.drawable.ic_default).into(holder.xavatar);

        }catch (Exception e){
            Toast.makeText(context, "Error al cargar la imagen", Toast.LENGTH_SHORT).show();

        }
        // click
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, ""+UsCorreo, Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {

        return usersList.size();
    }


}

package com.example.parcial3;

import static android.widget.Toast.LENGTH_SHORT;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class envdatos extends AppCompatActivity {

    EditText edinombre,ediedad,edigusto,correo;
    Button env;
    DatabaseReference informacion;
    FirebaseUser uid = FirebaseAuth.getInstance().getCurrentUser();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_envdatos);

        edinombre = findViewById(R.id.edinombre2);
        ediedad = findViewById(R.id.ediedad2);
        edigusto = findViewById(R.id.edigusto2);
        env = findViewById(R.id.env2);
        correo = findViewById(R.id.correo2);
        informacion = FirebaseDatabase.getInstance().getReference("usuario");


        env.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarusuario();
            }
        });

    }


    public void enviarusuario(){
        String msnnombre = edinombre.getText().toString();
        String msnedad = ediedad.getText().toString();
        // tambien se puede cambiar a una seleccion asi String msnnombre = nombre.getSelectecItem().toString();
        String msngustos = edigusto.getText().toString();
        String msncor = correo.getText().toString();

        if (!TextUtils.isEmpty(msnnombre)){
            if (!TextUtils.isEmpty(msnedad)){
                if (!TextUtils.isEmpty(msngustos)){
                    if (!TextUtils.isEmpty(msncor)) {
                        String id = uid.getUid();
                        usuario user = new usuario(id, msnnombre, msnedad, msngustos,msncor);
                        informacion.child("").child(id).setValue(user);
                        Toast.makeText(this, "Registrado", LENGTH_SHORT).show();
                    }
                }
            }
        }else{
            Toast.makeText(this,"No dejar en blanco", LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        // Aquí verificamos si estamos en el fragmento que queremos manejar al presionar "atrás"
        if (getSupportFragmentManager().findFragmentById(R.id.main) instanceof Usuariosfrag) {
            // Si estamos en el fragmento Usuariosfrag, volvemos al Activity principal
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            // Si no estamos en el fragmento Usuariosfrag, dejamos que la actividad maneje el comportamiento predeterminado
            super.onBackPressed();
        }
    }
}
package com.example.parcial3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class principal2 extends AppCompatActivity {

    TextView anom,nombre,artis;
    Button link,ejec;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal2);

        databaseReference = FirebaseDatabase.getInstance().getReference("musica");

        anom = findViewById(R.id.anom2);
        nombre=findViewById(R.id.nombrem2);
        artis=findViewById(R.id.artim2);

        link=findViewById(R.id.linkyt2);
        ejec=findViewById(R.id.ejecutar2);


        anom.setVisibility(View.GONE);
        nombre.setVisibility(View.GONE);
        artis.setVisibility(View.GONE);
        link.setVisibility(View.GONE);

        ejec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        long count = dataSnapshot.getChildrenCount();
                        long randomIndex = (long) (Math.random() * count) + 1;

                        DataSnapshot randomSnapshot = dataSnapshot.child(String.valueOf(randomIndex));

                        // Obtener los datos de la base de datos
                        String nombreMusica = String.valueOf(randomSnapshot.child("nombre").getValue());
                        String anomusica = String.valueOf(randomSnapshot.child("ano").getValue());
                        String artistaMusica = String.valueOf(randomSnapshot.child("artista").getValue());
                        String enlaceYoutube = String.valueOf(randomSnapshot.child("link").getValue());


                        // Mostrar los datos en tus TextViews
                        anom.setText(anomusica);
                        nombre.setText(nombreMusica);
                        artis.setText(artistaMusica);

                        // Hacer que los TextViews sean visibles
                        anom.setVisibility(View.VISIBLE);
                        nombre.setVisibility(View.VISIBLE);
                        artis.setVisibility(View.VISIBLE);

                        // Mostrar el botón de enlace y configurar su acción
                        link.setVisibility(View.VISIBLE);
                        link.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Abrir el enlace de YouTube en un navegador
                                if (enlaceYoutube != null && !enlaceYoutube.isEmpty()) {
                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(enlaceYoutube));
                                    startActivity(intent);
                                }
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Log.e("error", "Error en el codigo" );
                        Toast.makeText(getApplicationContext(),"Error de traer datos",Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
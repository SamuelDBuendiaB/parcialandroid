package com.example.parcial3;

public class modelUsers {
    // mismos datso que en firebase
    String nombre,edad,gusto,correo,imagen,buscar, usuarioid;

    public modelUsers() {
    }

    public modelUsers(String nombre, String edad, String gusto, String correo, String imagen, String buscar, String usuarioid) {
        this.nombre = nombre;
        this.edad = edad;
        this.gusto = gusto;
        this.correo = correo;
        this.imagen = imagen;
        this.buscar = buscar;
        this.usuarioid = usuarioid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getGusto() {
        return gusto;
    }

    public void setGusto(String gusto) {
        this.gusto = gusto;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public String getBuscar() {
        return buscar;
    }

    public void setBuscar(String buscar) {
        this.buscar = buscar;
    }

    public String getUsuarioid() {
        return usuarioid;
    }

    public void setUsuarioid(String usuarioid) {
        this.usuarioid = usuarioid;
    }
}

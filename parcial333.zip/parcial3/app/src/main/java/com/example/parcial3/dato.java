package com.example.parcial3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class dato extends AppCompatActivity {

    TextView anom,nombre,artis;
    Button link,ejec;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dato);
        anom = findViewById(R.id.anom2);
        nombre=findViewById(R.id.nombrem2);
        artis=findViewById(R.id.artim2);

        link=findViewById(R.id.linkyt2);
        ejec=findViewById(R.id.ejecutar2);


        anom.setVisibility(View.GONE);
        nombre.setVisibility(View.GONE);
        artis.setVisibility(View.GONE);
        link.setVisibility(View.GONE);

        ejec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                accion("http://10.0.2.2/apiparcial/ran.php");

            }
        });

    }

    private void accion(String URL) {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {
                try {
                    if (response.length() > 0) {
                        // Obtener el primer objeto del array
                        JSONObject jsonObject = response.getJSONObject(0);

                        anom.setVisibility(View.VISIBLE);
                        nombre.setVisibility(View.VISIBLE);
                        artis.setVisibility(View.VISIBLE);
                        link.setVisibility(View.VISIBLE);

                        anom.setText("Año: " + jsonObject.getString("ano"));
                        nombre.setText("Nombre: " + jsonObject.getString("nombre"));
                        artis.setText("Artista: " + jsonObject.getString("artista"));
                        final String youtubeLink = jsonObject.getString("linkyt");

                        // Configurar el botón para abrir el enlace
                        link.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Abrir el enlace
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeLink));
                                startActivity(intent);
                            }
                        });
                    } else {
                        Log.e("DatoActivity", "La respuesta está vacía");
                    }

                } catch (JSONException e) {
                    Log.e("DatoActivity", "Error al procesar JSON: " + e.getMessage());
                    Toast.makeText(getApplicationContext(), "Error al procesar JSON", Toast.LENGTH_SHORT).show();
                }
            }



        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                Log.e("error", "Salto directamenta aca: " );
                Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
            }
        }


        );
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }



}
package com.example.parcial3;

public class usuario {
    String usuarioid,nombre,edad,gusto,correo;
    public usuario(String usuarioid, String nombre, String edad, String gusto,String correo) {
        this.usuarioid = usuarioid;
        this.nombre = nombre;
        this.edad = edad;
        this.gusto = gusto;
        this.correo = correo;
    }

    public String getUsuarioid() {
        return usuarioid;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEdad() {
        return edad;
    }

    public String getGusto() {
        return gusto;
    }

    public String getCorreo() {
        return correo;
    }
}

public class usuario {

        public String nombre;
        public String edad;
        public String gusto;

        public usuario() {
            // Default constructor required for calls to DataSnapshot.getValue(usuario.class)
        }

        public usuario(String nombre, String edad, String gusto) {
            this.nombre = nombre;
            this.edad = edad;
            this.gusto = gusto;
        }
    }
}
